# FoundIt v3.0 - Ultimate Enterprise Edition
## Campus Lost & Found Platform | Hackathon & Final Year Project Turnaround

FoundIt v3.0 is a production-ready, enterprise-grade web application built to solve campus lost property management. It fulfills both static (HTML5/CSS Grid) and dynamic (TypeScript/Fetch API/Cosine Matching/SHA-256 Hashing) phases, while directly addressing every improvement area raised in the Attempt #3 Evaluation Report.

---

### 🚀 Key Improvements & Feature Matrix in v3.0

1. **Automated Unit & Integration Test Suite (`js/tests/engine.test.js`)**:
   - Executes live in the browser & Node.js environment.
   - Tests TF-IDF synonym matching, SHA-256 cryptographic hashing, XSS sanitization, input regex patterns, and duplicate report detection.

2. **Security & Cryptographic Proof Hashing (`js/services/security.js`)**:
   - Private ownership claim proofs are hashed using **SHA-256** (`crypto.subtle.digest`) before local/server persistence.
   - Guard desk authentication mode with PIN verification.
   - Comprehensive HTML entity XSS sanitization (`SecurityService.sanitizeHTML`).

3. **Intelligent Match Engine with Synonym Normalization (`js/services/matchingEngine.js`)**:
   - Domain-specific synonym expansion dictionary (e.g., *MacBook* ↔ *Apple Laptop*; *Hydro Flask* ↔ *Water Bottle*; *AirPods* ↔ *Headphones*).
   - Multi-attribute score weighting: Category (30%), Term Similarity (40%), Zone Proximity (15%), Incident Window Decay (15%), plus simulated MobileNet visual feature embeddings.

4. **Express.js Server API & Relational SQLite Schema (`server/`)**:
   - Fulfills the recommendation to move beyond LocalStorage with `server/server.js` (Express REST API) and `server/schema.sql` (Relational SQL tables & indexes).

5. **Stretch Features Implemented**:
   - **QR-Code Smart Property Tags**: Vector SVG QR tags generated for property affixing.
   - **Campus Security Custody Handover Receipts**: Printable custody certificates for items deposited at security desks.
   - **Automated Match SMS Alert Dispatcher**: Simulates real-time SMS alerts to students upon match detection.
   - **Database Export/Import**: Atomic JSON database backup export.

---

### 💻 Running the Application

#### Option A: Direct Web Browser Execution (No Installation Required)
1. Extract `foundit-prototype-v3.zip`.
2. Double-click `index.html` in any web browser.
3. Click on the **"📑 Guidelines & Test Suite"** tab to run the automated unit test harness live.

#### Option B: Express.js Backend Server Execution
```bash
cd server
npm install express cors
node server.js
```
Open `http://localhost:3000` to access the application via Node.js Express server.

---

### 📂 File Structure Overview

```
foundit-prototype-v3/
├── index.html                    # Responsive HTML5 SPA Shell
├── css/
│   └── styles.css                # Mobile-First CSS Grid layout & navy theme
├── js/
│   ├── api.js                    # Persistence Layer & 20-item dataset
│   ├── app.js                    # Main UI Controller & Modal Handlers
│   ├── services/
│   │   ├── matchingEngine.js     # Cosine similarity & duplicate detection
│   │   ├── security.js           # SHA-256 crypto hashing & XSS sanitizer
│   │   ├── qrGenerator.js        # SVG Smart Property Tag Generator
│   │   ├── receiptGenerator.js   # Handover Receipt Generator
│   │   └── smsSimulator.js       # SMS Alert Dispatcher
│   └── tests/
│       └── engine.test.js        # Executable unit test harness
├── server/
│   ├── server.js                 # Node.js / Express REST API
│   └── schema.sql                # SQLite Database Schema
├── src/
│   └── types.ts                  # TypeScript interfaces & API contracts
└── README.md                     # Documentation
```
