/**
 * FoundIt v3.0 - TypeScript Data Schemas & API Contracts
 * Enterprise & Production Grade Specifications
 */

export type ItemType = 'Lost' | 'Found';

export type ItemStatus = 'Open' | 'Claim Pending' | 'Resolved';

export type CampusLocation = 
  | 'Library' 
  | 'Main Building' 
  | 'Cafeteria' 
  | 'Sports Complex' 
  | 'Computer Lab 2' 
  | 'Gym' 
  | 'Main Gate';

export type ItemCategory = 
  | 'Electronics' 
  | 'ID Cards & Documents' 
  | 'Water Bottles' 
  | 'Keys' 
  | 'Bags & Backpacks' 
  | 'Clothing & Accessories';

export interface LostFoundItem {
  id: string;
  type: ItemType;
  title: string;
  category: ItemCategory;
  location: CampusLocation;
  date: string;
  description: string;
  photoUrl: string;
  status: ItemStatus;
  createdAt: string;
  reporterName?: string;
  reporterPhone?: string;
  reporterEmail?: string;
  privateVerificationNote?: string;
  featureVector?: number[]; // For simulated MobileNet AI embeddings
}

export interface ClaimRequest {
  id: string;
  itemId: string;
  claimantName: string;
  claimantEmail: string;
  claimantPhone: string;
  privateProofHash: string; // SHA-256 Hashed proof
  privateProofHint: string;  // Plaintext non-sensitive hint
  submittedAt: string;
  status: 'Pending Review' | 'Approved' | 'Rejected';
  reviewedBy?: string;
  reviewNotes?: string;
}

export interface MatchResult {
  id: string;
  lostItem: LostFoundItem;
  foundItem: LostFoundItem;
  confidenceScore: number; // 0 to 100
  matchingFactors: string[];
  isDuplicateReport?: boolean;
}

export interface CustodyReceipt {
  receiptId: string;
  itemId: string;
  itemTitle: string;
  itemCategory: string;
  locationFound: CampusLocation;
  guardOnDuty: string;
  guardBadgeId: string;
  timestamp: string;
  securityDeskLocation: string;
  status: string;
}

export interface SMSNotification {
  id: string;
  recipientPhone: string;
  itemTitle: string;
  matchScore: number;
  sentAt: string;
  messageText: string;
  status: 'Delivered' | 'Pending';
}

export interface UserSession {
  role: 'Student' | 'SecurityGuard';
  guardBadgeId?: string;
  guardName?: string;
}
