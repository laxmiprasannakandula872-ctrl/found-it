/**
 * FoundIt v3.0 Express.js Backend Server API
 * Fulfills SRS Express/Node.js backend recommendations with RESTful routes
 */

const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../')));

// In-Memory SQLite API simulation layer
let itemsDB = [];
let claimsDB = [];

// REST API Endpoints
app.get('/api/items', (req, res) => {
  res.json({ success: true, count: itemsDB.length, data: itemsDB });
});

app.post('/api/items', (req, res) => {
  const item = { id: `item_${Date.now()}`, ...req.body, createdAt: new Date().toISOString() };
  itemsDB.unshift(item);
  res.status(201).json({ success: true, data: item });
});

app.post('/api/claims', (req, res) => {
  const claim = { id: `claim_${Date.now()}`, ...req.body, status: 'Pending Review', submittedAt: new Date().toISOString() };
  claimsDB.unshift(claim);
  
  // Update item status
  const targetItem = itemsDB.find(i => i.id === claim.itemId);
  if (targetItem) targetItem.status = 'Claim Pending';

  res.status(201).json({ success: true, data: claim });
});

app.get('/api/health', (req, res) => {
  res.json({ status: 'HEALTHY', system: 'FoundIt Express API v3.0', uptime: process.uptime() });
});

if (require.main === module) {
  app.listen(PORT, () => console.log(`FoundIt Backend running on http://localhost:${PORT}`));
}

module.exports = app;
