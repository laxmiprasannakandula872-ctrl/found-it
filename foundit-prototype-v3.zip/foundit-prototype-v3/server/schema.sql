-- FoundIt v3.0 SQLite Relational Database Schema
-- Addressing System Design & Scalability recommendations from Project Evaluation Report

CREATE TABLE IF NOT EXISTS items (
    id TEXT PRIMARY KEY,
    type TEXT NOT NULL CHECK(type IN ('Lost', 'Found')),
    title TEXT NOT NULL,
    category TEXT NOT NULL,
    location TEXT NOT NULL,
    date TEXT NOT NULL,
    description TEXT,
    photo_url TEXT,
    status TEXT NOT NULL DEFAULT 'Open' CHECK(status IN ('Open', 'Claim Pending', 'Resolved')),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    reporter_name TEXT,
    reporter_phone TEXT
);

CREATE TABLE IF NOT EXISTS claim_requests (
    id TEXT PRIMARY KEY,
    item_id TEXT NOT NULL,
    claimant_name TEXT NOT NULL,
    claimant_email TEXT NOT NULL,
    claimant_phone TEXT,
    private_proof_hash TEXT NOT NULL,
    private_proof_hint TEXT,
    submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    status TEXT NOT NULL DEFAULT 'Pending Review',
    FOREIGN KEY(item_id) REFERENCES items(id)
);

CREATE TABLE IF NOT EXISTS custody_receipts (
    receipt_id TEXT PRIMARY KEY,
    item_id TEXT NOT NULL,
    guard_on_duty TEXT NOT NULL,
    guard_badge_id TEXT NOT NULL,
    security_desk TEXT NOT NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(item_id) REFERENCES items(id)
);

CREATE INDEX IF NOT EXISTS idx_items_category ON items(category);
CREATE INDEX IF NOT EXISTS idx_items_location ON items(location);
CREATE INDEX IF NOT EXISTS idx_items_status ON items(status);
