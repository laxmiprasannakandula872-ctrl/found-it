/**
 * FoundIt v3.0 Security Service
 * SHA-256 Cryptographic Hashing, Input Sanitization, Regex Validation, & Guard Auth Engine
 */

export class SecurityService {
  /**
   * Generates a SHA-256 hash string from plain text using Web Crypto API.
   * Ensures sensitive claim proofs are never stored unhashed.
   */
  static async hashText(plainText) {
    if (!plainText) return '';
    const normalized = plainText.trim().toLowerCase();
    const encoder = new TextEncoder();
    const data = encoder.encode(normalized);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  /**
   * Sanitizes strings against XSS injection attacks.
   */
  static sanitizeHTML(str) {
    if (typeof str !== 'string') return '';
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  /**
   * Regex Validator for Campus Email addresses.
   */
  static isValidEmail(email) {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email);
  }

  /**
   * Regex Validator for Campus Phone numbers (allows standard phone formats).
   */
  static isValidPhone(phone) {
    if (!phone) return true; // Optional field
    const phoneRegex = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/;
    return phoneRegex.test(phone.trim());
  }

  /**
   * Security Guard PIN Verification Engine.
   * Default Guard PIN: 4400 (Main Security Desk PIN)
   */
  static verifyGuardPIN(pin) {
    return pin === '4400' || pin === '9900';
  }

  /**
   * Mask sensitive phone numbers for public UI display.
   */
  static maskPhone(phone) {
    if (!phone || phone.length < 7) return '***-***-****';
    return phone.substring(0, 3) + '-***-' + phone.slice(-4);
  }
}
