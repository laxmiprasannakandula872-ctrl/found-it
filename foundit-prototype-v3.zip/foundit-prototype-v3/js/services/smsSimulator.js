/**
 * FoundIt v3.0 SMS Alert Simulator Service
 * Simulates real-time automated SMS notifications to students upon match detection
 */

export class SMSSimulatorService {
  static smsLog = [];

  /**
   * Triggers an automated SMS notification when a probable match is detected.
   */
  static triggerMatchAlert(reporterPhone, itemTitle, matchScore, foundLocation) {
    if (!reporterPhone) return null;
    
    const sms = {
      id: `sms_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      recipientPhone: reporterPhone,
      itemTitle,
      matchScore,
      sentAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      messageText: `[FoundIt Alert] A potential match (${matchScore}% match confidence) was reported at ${foundLocation} for your lost '${itemTitle}'. Log into FoundIt to submit ownership verification!`,
      status: 'Delivered'
    };

    this.smsLog.unshift(sms);
    return sms;
  }

  static getSMSHistory() {
    return this.smsLog;
  }
}
