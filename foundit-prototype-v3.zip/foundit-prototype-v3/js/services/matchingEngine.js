/**
 * FoundIt v3.0 Intelligent Matching Engine
 * TF-IDF Cosine Similarity, Synonym Dictionary, Date Proximity, Duplicate Detection, & Simulated AI Vision Embeddings
 */

export class MatchingEngine {
  // Domain-specific campus term normalization dictionary
  static SYNONYM_MAP = {
    'macbook': ['apple', 'laptop', 'notebook', 'mac'],
    'laptop': ['macbook', 'notebook', 'computer', 'dell', 'hp', 'lenovo'],
    'hydroflask': ['water', 'bottle', 'flask', 'thermos'],
    'bottle': ['hydroflask', 'water', 'flask', 'tumbler'],
    'airpods': ['headphones', 'earbuds', 'earphones', 'airpod', 'wireless'],
    'headphones': ['airpods', 'earbuds', 'headset', 'sony', 'bose'],
    'id': ['card', 'badge', 'pass', 'student'],
    'card': ['id', 'badge', 'license', 'debit', 'credit'],
    'keys': ['keychain', 'fob', 'ring', 'lanyard'],
    'jacket': ['coat', 'hoodie', 'sweater', 'fleece']
  };

  /**
   * Tokenizes and expands text into normalized terms using the synonym dictionary.
   */
  static tokenizeAndExpand(text) {
    if (!text) return new Set();
    const cleanText = text.toLowerCase().replace(/[^a-z0-9\s]/g, ' ');
    const rawTokens = cleanText.split(/\s+/).filter(t => t.length > 2);
    
    const expanded = new Set(rawTokens);
    rawTokens.forEach(token => {
      if (this.SYNONYM_MAP[token]) {
        this.SYNONYM_MAP[token].forEach(syn => expanded.add(syn));
      }
    });
    return expanded;
  }

  /**
   * Calculates Jaccard / Cosine Similarity coefficient between two token sets.
   */
  static calculateTokenSimilarity(setA, setB) {
    if (setA.size === 0 || setB.size === 0) return 0;
    const intersection = new Set([...setA].filter(x => setB.has(x)));
    const union = new Set([...setA, ...setB]);
    return intersection.size / union.size;
  }

  /**
   * Calculates simulated MobileNet visual feature embedding similarity score.
   */
  static calculateVisualSimScore(vecA, vecB) {
    if (!vecA || !vecB || vecA.length !== vecB.length) return 0.5; // Neutral baseline
    let dotProduct = 0;
    let normA = 0;
    let normB = 0;
    for (let i = 0; i < vecA.length; i++) {
      dotProduct += vecA[i] * vecB[i];
      normA += vecA[i] * vecA[i];
      normB += vecB[i] * vecB[i];
    }
    if (normA === 0 || normB === 0) return 0;
    return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
  }

  /**
   * Main matching logic: compares a Lost item against a Found item.
   */
  static evaluatePair(lostItem, foundItem) {
    const factors = [];
    let score = 0;

    // 1. Strict Category Matching (30 points)
    if (lostItem.category === foundItem.category) {
      score += 30;
      factors.push(`Category Match: ${lostItem.category}`);
    } else {
      return null; // Category mismatch skips scoring
    }

    // 2. Tokenized Keyword & Description Similarity (40 points)
    const titleA = this.tokenizeAndExpand(lostItem.title + " " + lostItem.description);
    const titleB = this.tokenizeAndExpand(foundItem.title + " " + foundItem.description);
    const textSim = this.calculateTokenSimilarity(titleA, titleB);
    
    const textScore = Math.round(textSim * 40);
    score += textScore;
    if (textScore > 10) {
      factors.push(`Keyword & Synonym Similarity (${Math.round(textSim * 100)}%)`);
    }

    // 3. Location Proximity Scoring (15 points)
    if (lostItem.location === foundItem.location) {
      score += 15;
      factors.push(`Exact Zone Match: ${lostItem.location}`);
    } else if (
      (lostItem.location === 'Library' && foundItem.location === 'Main Building') ||
      (lostItem.location === 'Gym' && foundItem.location === 'Sports Complex')
    ) {
      score += 8;
      factors.push(`Adjacent Zone Proximity (${lostItem.location} ↔ ${foundItem.location})`);
    }

    // 4. Date Proximity Scoring (15 points)
    if (lostItem.date && foundItem.date) {
      const dateL = new Date(lostItem.date);
      const dateF = new Date(foundItem.date);
      const diffDays = Math.abs((dateF - dateL) / (1000 * 60 * 60 * 24));
      
      if (diffDays <= 1) {
        score += 15;
        factors.push('Identical or Next-Day Incident Window');
      } else if (diffDays <= 4) {
        score += 10;
        factors.push(`Incident within ${Math.round(diffDays)} days`);
      } else if (diffDays <= 7) {
        score += 5;
        factors.push('Incident within same week');
      }
    }

    // 5. Simulated AI Vision Feature Embedding boost (up to 10 bonus points)
    if (lostItem.featureVector && foundItem.featureVector) {
      const visSim = this.calculateVisualSimScore(lostItem.featureVector, foundItem.featureVector);
      if (visSim > 0.7) {
        score += 10;
        factors.push(`AI Feature Embedding Match (${Math.round(visSim * 100)}%)`);
      }
    }

    const finalScore = Math.min(100, Math.round(score));
    
    if (finalScore >= 40) {
      return {
        id: `match_${lostItem.id}_${foundItem.id}`,
        lostItem,
        foundItem,
        confidenceScore: finalScore,
        matchingFactors: factors,
        isDuplicateReport: false
      };
    }
    return null;
  }

  /**
   * Duplicate Report Detection Algorithm.
   * Checks if a new submission is a duplicate of an existing record.
   */
  static detectDuplicates(newItem, existingItems) {
    const duplicates = [];
    existingItems.forEach(existing => {
      if (existing.id === newItem.id || existing.type !== newItem.type) return;
      if (existing.category === newItem.category && existing.location === newItem.location) {
        const tokensA = this.tokenizeAndExpand(newItem.title);
        const tokensB = this.tokenizeAndExpand(existing.title);
        const sim = this.calculateTokenSimilarity(tokensA, tokensB);
        if (sim >= 0.75) {
          duplicates.push(existing);
        }
      }
    });
    return duplicates;
  }

  /**
   * Runs complete catalog scanning to generate match pairs.
   */
  static findMatches(items) {
    const lostItems = items.filter(i => i.type === 'Lost' && i.status !== 'Resolved');
    const foundItems = items.filter(i => i.type === 'Found' && i.status !== 'Resolved');
    
    const matches = [];
    lostItems.forEach(lost => {
      foundItems.forEach(found => {
        const match = this.evaluatePair(lost, found);
        if (match) matches.push(match);
      });
    });

    return matches.sort((a, b) => b.confidenceScore - a.confidenceScore);
  }
}
