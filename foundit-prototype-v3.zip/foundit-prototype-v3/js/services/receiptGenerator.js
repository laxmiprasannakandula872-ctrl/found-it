/**
 * FoundIt v3.0 Custody Handover Receipt & Transfer Generator
 */

export class ReceiptGeneratorService {
  /**
   * Generates a printable Custody Handover Receipt HTML template.
   */
  static generateReceiptHTML(receipt) {
    return `
      <div class="receipt-card">
        <div class="receipt-header">
          <div class="receipt-badge">OFFICIAL CAMPUS RECEIPT</div>
          <h3>Custody Handover Certificate</h3>
          <p class="receipt-id">Receipt #${receipt.receiptId}</p>
        </div>
        <div class="receipt-body">
          <div class="receipt-row"><span>Item Logged:</span> <strong>${receipt.itemTitle}</strong></div>
          <div class="receipt-row"><span>Category:</span> <strong>${receipt.itemCategory}</strong></div>
          <div class="receipt-row"><span>Found Location:</span> <strong>${receipt.locationFound}</strong></div>
          <div class="receipt-row"><span>Security Desk:</span> <strong>${receipt.securityDeskLocation}</strong></div>
          <div class="receipt-row"><span>Guard on Duty:</span> <strong>${receipt.guardOnDuty} (ID: ${receipt.guardBadgeId})</strong></div>
          <div class="receipt-row"><span>Date & Time:</span> <strong>${receipt.timestamp}</strong></div>
          <div class="receipt-row"><span>Custody Status:</span> <span class="status-pill status-open">${receipt.status}</span></div>
        </div>
        <div class="receipt-footer">
          <p>This digital receipt confirms physical transfer of lost property into campus security vault custody.</p>
          <div class="signature-line">Security Desk Stamp / Digital Signature Verified</div>
        </div>
      </div>
    `;
  }
}
