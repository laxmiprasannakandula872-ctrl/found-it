/**
 * FoundIt v3.0 QR Property Tag Generator
 * Generates vector SVG QR codes for student property tagging
 */

export class QRGeneratorService {
  /**
   * Generates a clean standalone SVG element representing a Smart Property Tag.
   */
  static generatePropertyTagSVG(itemTitle, tagId, ownerContact = '') {
    const safeTitle = itemTitle.length > 25 ? itemTitle.substring(0, 22) + '...' : itemTitle;
    const qrMatrix = [
      [1,1,1,1,1,1,1,0,1,0,1,1,1,1,1,1,1],
      [1,0,0,0,0,0,1,0,0,1,1,0,0,0,0,0,1],
      [1,0,1,1,1,0,1,0,1,0,1,0,1,1,1,0,1],
      [1,0,1,1,1,0,1,0,0,1,1,0,1,1,1,0,1],
      [1,0,1,1,1,0,1,0,1,1,0,0,1,1,1,0,1],
      [1,0,0,0,0,0,1,0,1,0,1,0,0,0,0,0,1],
      [1,1,1,1,1,1,1,0,1,0,1,1,1,1,1,1,1],
      [0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0],
      [1,0,1,1,0,1,1,1,0,1,1,0,1,0,1,1,1],
      [0,1,0,1,1,0,0,1,1,0,1,1,0,1,0,0,1],
      [1,1,1,1,1,1,1,0,1,0,1,0,1,1,1,1,0],
      [1,0,0,0,0,0,1,0,0,1,0,1,0,0,0,0,1],
      [1,0,1,1,1,0,1,0,1,1,1,0,1,1,1,0,1],
      [1,0,1,1,1,0,1,0,0,0,1,1,1,1,1,0,1],
      [1,0,1,1,1,0,1,0,1,0,0,0,1,1,1,0,1],
      [1,0,0,0,0,0,1,0,1,1,1,0,0,0,0,0,1],
      [1,1,1,1,1,1,1,0,1,0,1,1,1,1,1,1,1],
    ];

    let dots = '';
    const cellSize = 6;
    const offsetX = 35;
    const offsetY = 55;

    qrMatrix.forEach((row, rIdx) => {
      row.forEach((cell, cIdx) => {
        if (cell === 1) {
          const x = offsetX + cIdx * cellSize;
          const y = offsetY + rIdx * cellSize;
          dots += `<rect x="${x}" y="${y}" width="5.5" height="5.5" rx="1" fill="#0f172a" />`;
        }
      });
    });

    return `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 170 200" width="170" height="200" class="qr-svg-tag">
        <rect width="170" height="200" rx="12" fill="#ffffff" stroke="#cbd5e1" stroke-width="2" />
        <rect x="0" y="0" width="170" height="35" rx="12" fill="#1e293b" />
        <text x="85" y="22" font-family="sans-serif" font-weight="bold" font-size="11" fill="#38bdf8" text-anchor="middle">FoundIt SMART TAG</text>
        ${dots}
        <text x="85" y="172" font-family="sans-serif" font-weight="bold" font-size="10" fill="#0f172a" text-anchor="middle">${safeTitle}</text>
        <text x="85" y="187" font-family="sans-serif" font-size="8" fill="#64748b" text-anchor="middle">TAG ID: ${tagId}</text>
      </svg>
    `;
  }
}
