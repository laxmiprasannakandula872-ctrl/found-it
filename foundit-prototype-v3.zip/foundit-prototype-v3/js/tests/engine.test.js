/**
 * FoundIt v3.0 Automated Test Suite
 * Evaluates core matching algorithms, SHA-256 security hashing, XSS sanitization, and duplicate detection
 */

import { MatchingEngine } from '../services/matchingEngine.js';
import { SecurityService } from '../services/security.js';
import { SMSSimulatorService } from '../services/smsSimulator.js';

export class EngineTestSuite {
  static runAllTests() {
    const results = [];

    // Test 1: Synonym expansion & Cosine matching
    try {
      const lostItem = {
        id: 'test_1',
        type: 'Lost',
        title: 'Lost MacBook Pro laptop',
        category: 'Electronics',
        location: 'Library',
        date: '2026-11-19',
        description: 'Space gray laptop with stickers'
      };
      const foundItem = {
        id: 'test_2',
        type: 'Found',
        title: 'Found Apple Notebook computer',
        category: 'Electronics',
        location: 'Library',
        date: '2026-11-19',
        description: 'Gray Apple notebook found on 2nd floor desk'
      };

      const match = MatchingEngine.evaluatePair(lostItem, foundItem);
      const passed = match !== null && match.confidenceScore >= 70;
      results.push({
        name: 'Matching Engine: Synonym Token Expansion (MacBook ↔ Apple Notebook)',
        passed,
        details: passed ? `Passed with ${match.confidenceScore}% confidence score` : 'Failed to score match above 70%'
      });
    } catch (err) {
      results.push({ name: 'Matching Engine: Synonym Token Expansion', passed: false, details: err.message });
    }

    // Test 2: SHA-256 Security Hashing
    try {
      const p1 = SecurityService.hashText('Blue Hydro Flask with sticker');
      const p2 = SecurityService.hashText('blue hydro flask with sticker');
      
      Promise.all([p1, p2]).then(([h1, h2]) => {
        const passed = h1.length === 64 && h1 === h2;
        results.push({
          name: 'Security: SHA-256 Hashing & Case Normalization',
          passed,
          details: passed ? `SHA-256 Hash generated: ${h1.substring(0, 16)}...` : 'Hashes did not match'
        });
      });
    } catch (err) {
      results.push({ name: 'Security: SHA-256 Hashing', passed: false, details: err.message });
    }

    // Test 3: XSS Sanitization
    try {
      const maliciousInput = '<script>alert("hack")</script>';
      const sanitized = SecurityService.sanitizeHTML(maliciousInput);
      const passed = !sanitized.includes('<script>') && sanitized.includes('&lt;script&gt;');
      results.push({
        name: 'Security: HTML Entity XSS Sanitization',
        passed,
        details: passed ? `Sanitized output: ${sanitized}` : 'Failed to sanitize script tag'
      });
    } catch (err) {
      results.push({ name: 'Security: HTML Entity XSS Sanitization', passed: false, details: err.message });
    }

    // Test 4: Duplicate Report Detection
    try {
      const existing = [
        { id: 'item_101', type: 'Lost', title: 'Black Hydro Flask', category: 'Water Bottles', location: 'Gym' }
      ];
      const newItem = { id: 'item_102', type: 'Lost', title: 'Black Hydroflask Water Bottle', category: 'Water Bottles', location: 'Gym' };
      const duplicates = MatchingEngine.detectDuplicates(newItem, existing);
      const passed = duplicates.length > 0;
      results.push({
        name: 'System Design: Algorithmic Duplicate Report Detection',
        passed,
        details: passed ? `Detected duplicate item ID: ${duplicates[0].id}` : 'Failed to flag duplicate'
      });
    } catch (err) {
      results.push({ name: 'System Design: Duplicate Detection', passed: false, details: err.message });
    }

    // Test 5: Regex Email & Phone Validators
    try {
      const validEmail = SecurityService.isValidEmail('student@campus.edu');
      const invalidEmail = SecurityService.isValidEmail('invalid-email-str');
      const passed = validEmail && !invalidEmail;
      results.push({
        name: 'Requirements: Input Validation Regex Patterns',
        passed,
        details: passed ? 'Validated campus email regex patterns successfully' : 'Regex failed email check'
      });
    } catch (err) {
      results.push({ name: 'Requirements: Input Validation Regex', passed: false, details: err.message });
    }

    // Test 6: Automated SMS Simulator
    try {
      const sms = SMSSimulatorService.triggerMatchAlert('555-0199', 'Sony Headphones', 88, 'Library');
      const passed = sms !== null && sms.status === 'Delivered';
      results.push({
        name: 'Innovation: Automated Match SMS Alert Dispatcher',
        passed,
        details: passed ? `Simulated SMS dispatched to ${sms.recipientPhone}` : 'Failed to dispatch SMS'
      });
    } catch (err) {
      results.push({ name: 'Innovation: SMS Alert Dispatcher', passed: false, details: err.message });
    }

    return results;
  }
}
