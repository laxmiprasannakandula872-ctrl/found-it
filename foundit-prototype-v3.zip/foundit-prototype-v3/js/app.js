/**
 * FoundIt v3.0 Main Application Controller
 * Dynamic UI Routing, Filter Controls, Claim Engine, Guard Portal, & Test Harness
 */

import { FoundItAPI } from './api.js';
import { MatchingEngine } from './services/matchingEngine.js';
import { SecurityService } from './services/security.js';
import { QRGeneratorService } from './services/qrGenerator.js';
import { ReceiptGeneratorService } from './services/receiptGenerator.js';
import { SMSSimulatorService } from './services/smsSimulator.js';
import { EngineTestSuite } from './tests/engine.test.js';

document.addEventListener('DOMContentLoaded', () => {
  // Initialize Storage
  FoundItAPI.initStorage();

  // State Variables
  let activeTab = 'gallery-tab';
  let items = FoundItAPI.getItems();
  let currentClaimItemId = null;
  let isGuardAuthenticated = false;

  // DOM Elements
  const navBtns = document.querySelectorAll('.nav-btn');
  const tabContents = document.querySelectorAll('.tab-content');
  const itemGrid = document.getElementById('item-grid');
  const searchInput = document.getElementById('search-input');
  const categoryFilter = document.getElementById('category-filter');
  const locationFilter = document.getElementById('location-filter');
  const typeFilter = document.getElementById('type-filter');

  // Modal Elements
  const claimModal = document.getElementById('claim-modal');
  const reportForm = document.getElementById('report-item-form');

  // Navigation Logic
  navBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      navBtns.forEach(b => b.classList.remove('active'));
      tabContents.forEach(t => t.classList.remove('active'));
      
      btn.classList.add('active');
      activeTab = btn.dataset.tab;
      document.getElementById(activeTab).classList.add('active');

      if (activeTab === 'matches-tab') renderMatches();
      if (activeTab === 'claims-tab') renderAdminClaims();
      if (activeTab === 'tests-tab') runTestSuite();
    });
  });

  // Render Item Gallery Grid
  function renderGallery() {
    items = FoundItAPI.getItems();
    const query = searchInput.value.toLowerCase().trim();
    const selectedCategory = categoryFilter.value;
    const selectedLocation = locationFilter.value;
    const selectedType = typeFilter.value;

    const filtered = items.filter(item => {
      const matchesSearch = item.title.toLowerCase().includes(query) ||
                            item.description.toLowerCase().includes(query);
      const matchesCategory = !selectedCategory || item.category === selectedCategory;
      const matchesLocation = !selectedLocation || item.location === selectedLocation;
      const matchesType = !selectedType || item.type === selectedType;

      return matchesSearch && matchesCategory && matchesLocation && matchesType;
    });

    itemGrid.innerHTML = filtered.map(item => `
      <div class="card">
        <div class="card-img-container">
          <img src="${item.photoUrl}" alt="${SecurityService.sanitizeHTML(item.title)}" class="card-img" onerror="this.src='data:image/svg+xml;utf8,<svg xmlns=\\'http://www.w3.org/2000/svg\\' width=\\'300\\' height=\\'200\\'><rect width=\\'300\\' height=\\'200\\' fill=\\'%231e293b\\'/><text x=\\'50%\\' y=\\'50%\\' fill=\\'%2338bdf8\\' text-anchor=\\'middle\\'>No Image</text></svg>'">
          <span class="badge-pill ${item.type === 'Lost' ? 'badge-type-lost' : 'badge-type-found'}">${item.type}</span>
          <span class="status-pill status-${item.status === 'Open' ? 'open' : item.status === 'Claim Pending' ? 'pending' : 'resolved'}">${item.status}</span>
        </div>
        <div class="card-body">
          <h3 class="card-title">${SecurityService.sanitizeHTML(item.title)}</h3>
          <div class="card-meta">
            <span>📍 ${item.location}</span>
            <span>📅 ${item.date}</span>
            <span>🏷️ ${item.category}</span>
          </div>
          <p class="card-desc">${SecurityService.sanitizeHTML(item.description)}</p>
          <div class="card-footer">
            ${item.type === 'Found' && item.status === 'Open' ? `
              <button class="btn btn-primary claim-btn" data-id="${item.id}">Claim Item</button>
            ` : `
              <span class="status-info">${item.status}</span>
            `}
            <button class="btn btn-secondary qr-btn" data-title="${SecurityService.sanitizeHTML(item.title)}" data-id="${item.id}">QR Tag</button>
          </div>
        </div>
      </div>
    `).join('');

    // Attach Event Listeners
    document.querySelectorAll('.claim-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        currentClaimItemId = e.target.dataset.id;
        openClaimModal(currentClaimItemId);
      });
    });

    document.querySelectorAll('.qr-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const title = e.target.dataset.title;
        const id = e.target.dataset.id;
        showQRTagModal(title, id);
      });
    });
  }

  // Real-Time Filter Event Listeners
  [searchInput, categoryFilter, locationFilter, typeFilter].forEach(el => {
    el.addEventListener('input', renderGallery);
  });

  // Report Console Form Handler
  reportForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const type = document.getElementById('report-type').value;
    const title = document.getElementById('report-title').value.trim();
    const category = document.getElementById('report-category').value;
    const location = document.getElementById('report-location').value;
    const date = document.getElementById('report-date').value;
    const description = document.getElementById('report-desc').value.trim();
    const reporterName = document.getElementById('report-name').value.trim();
    const reporterPhone = document.getElementById('report-phone').value.trim();

    if (!SecurityService.isValidPhone(reporterPhone)) {
      alert('Please enter a valid phone number format.');
      return;
    }

    const newItem = {
      id: `item_${Date.now()}`,
      type,
      title,
      category,
      location,
      date,
      description,
      photoUrl: FoundItAPI.PLACEHOLDER_IMG,
      status: 'Open',
      createdAt: new Date().toISOString(),
      reporterName,
      reporterPhone
    };

    // Check for Duplicates
    const existing = FoundItAPI.getItems();
    const duplicates = MatchingEngine.detectDuplicates(newItem, existing);
    if (duplicates.length > 0) {
      const confirmProceed = confirm(`Notice: A similar item (${duplicates[0].title}) has already been reported. Submit anyway?`);
      if (!confirmProceed) return;
    }

    FoundItAPI.saveItem(newItem);
    
    // Check if new Found item triggers SMS Alert to any Lost report
    if (type === 'Found') {
      const matches = MatchingEngine.findMatches(FoundItAPI.getItems());
      const relevantMatch = matches.find(m => m.foundItem.id === newItem.id && m.confidenceScore >= 70);
      if (relevantMatch && relevantMatch.lostItem.reporterPhone) {
        SMSSimulatorService.triggerMatchAlert(
          relevantMatch.lostItem.reporterPhone,
          newItem.title,
          relevantMatch.confidenceScore,
          newItem.location
        );
        alert(`🎉 Item saved! High Confidence Match (${relevantMatch.confidenceScore}%) detected! Simulated SMS alert dispatched to lost item reporter.`);
      } else {
        alert('Item logged successfully in FoundIt database!');
      }
    } else {
      alert('Lost Item logged successfully!');
    }

    reportForm.reset();
    renderGallery();
    document.querySelector('[data-tab="gallery-tab"]').click();
  });

  // Render Smart Matching Drawer
  function renderMatches() {
    const container = document.getElementById('matches-container');
    const allItems = FoundItAPI.getItems();
    const matches = MatchingEngine.findMatches(allItems);

    if (matches.length === 0) {
      container.innerHTML = '<p class="text-muted">No high-confidence matches detected between Lost and Found reports currently.</p>';
      return;
    }

    container.innerHTML = matches.map(m => `
      <div class="match-card">
        <div>
          <span class="badge-pill badge-type-lost">LOST</span>
          <h4>${SecurityService.sanitizeHTML(m.lostItem.title)}</h4>
          <p class="text-muted">📍 ${m.lostItem.location} | 📅 ${m.lostItem.date}</p>
        </div>
        <div>
          <span class="badge-pill badge-type-found">FOUND</span>
          <h4>${SecurityService.sanitizeHTML(m.foundItem.title)}</h4>
          <p class="text-muted">📍 ${m.foundItem.location} | 📅 ${m.foundItem.date}</p>
        </div>
        <div>
          <div class="match-score-pill">${m.confidenceScore}% MATCH</div>
          <button class="btn btn-primary claim-btn" style="margin-top: 0.5rem; width: 100%;" data-id="${m.foundItem.id}">Initiate Claim</button>
        </div>
      </div>
    `).join('');
  }

  // Open Claim Modal with SHA-256 Hash Protection
  function openClaimModal(itemId) {
    const modalItemTitle = document.getElementById('claim-item-title');
    const item = items.find(i => i.id === itemId);
    if (item) {
      modalItemTitle.textContent = item.title;
      claimModal.classList.add('active');
    }
  }

  document.getElementById('close-claim-modal').addEventListener('click', () => {
    claimModal.classList.remove('active');
  });

  document.getElementById('claim-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const claimantName = document.getElementById('claimant-name').value.trim();
    const claimantEmail = document.getElementById('claimant-email').value.trim();
    const claimantPhone = document.getElementById('claimant-phone').value.trim();
    const privateProof = document.getElementById('claim-proof').value.trim();

    if (!SecurityService.isValidEmail(claimantEmail)) {
      alert('Please enter a valid campus email address.');
      return;
    }

    // SHA-256 Hashing of Private Verification Proof
    const hashedProof = await SecurityService.hashText(privateProof);

    const claim = {
      id: `claim_${Date.now()}`,
      itemId: currentClaimItemId,
      claimantName,
      claimantEmail,
      claimantPhone,
      privateProofHash: hashedProof,
      privateProofHint: privateProof.substring(0, 15) + '...',
      submittedAt: new Date().toLocaleString(),
      status: 'Pending Review'
    };

    FoundItAPI.submitClaim(claim);
    alert('Ownership Claim submitted with SHA-256 cryptographic verification proof!');
    claimModal.classList.remove('active');
    renderGallery();
  });

  // Security Guard Portal Auth
  document.getElementById('guard-login-btn').addEventListener('click', () => {
    const pin = prompt('Enter Security Guard PIN (Default Desk PIN: 4400):');
    if (SecurityService.verifyGuardPIN(pin)) {
      isGuardAuthenticated = true;
      alert('Security Guard Authentication Successful! Guard Access Granted.');
      renderAdminClaims();
    } else {
      alert('Invalid Security PIN.');
    }
  });

  function renderAdminClaims() {
    const container = document.getElementById('claims-list-container');
    const claims = FoundItAPI.getClaims();

    if (!isGuardAuthenticated) {
      container.innerHTML = `
        <div class="hero-card">
          <div>
            <h3>🔒 Security Desk Auth Required</h3>
            <p>Accessing private claim verification hashes requires Security Guard Authentication.</p>
          </div>
          <button class="btn btn-primary" id="trigger-guard-login">Authenticate as Guard</button>
        </div>
      `;
      document.getElementById('trigger-guard-login').addEventListener('click', () => {
        document.getElementById('guard-login-btn').click();
      });
      return;
    }

    if (claims.length === 0) {
      container.innerHTML = '<p class="text-muted">No pending ownership claim tickets currently.</p>';
      return;
    }

    container.innerHTML = claims.map(c => `
      <div class="match-card">
        <div>
          <h4>Claim Ticket #${c.id}</h4>
          <p>Claimant: <strong>${SecurityService.sanitizeHTML(c.claimantName)}</strong> (${c.claimantEmail})</p>
          <p>Submitted: ${c.submittedAt}</p>
        </div>
        <div>
          <p>🔒 <strong>SHA-256 Proof Hash:</strong></p>
          <code style="font-size:0.75rem; color: var(--primary);">${c.privateProofHash}</code>
        </div>
        <div>
          <button class="btn btn-primary generate-receipt-btn" data-claimid="${c.id}" data-itemid="${c.itemId}">Generate Handover Receipt</button>
        </div>
      </div>
    `).join('');

    document.querySelectorAll('.generate-receipt-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const itemId = e.target.dataset.itemid;
        const item = items.find(i => i.id === itemId);
        
        const receipt = {
          receiptId: `REC_${Date.now().toString().slice(-6)}`,
          itemId: item.id,
          itemTitle: item.title,
          itemCategory: item.category,
          locationFound: item.location,
          guardOnDuty: 'Officer Davis',
          guardBadgeId: 'OFFICER_4400',
          timestamp: new Date().toLocaleString(),
          securityDeskLocation: 'Main Campus Gate Security Office',
          status: 'Resolved & Released'
        };

        FoundItAPI.saveReceipt(receipt);
        FoundItAPI.updateItemStatus(itemId, 'Resolved');

        const receiptHTML = ReceiptGeneratorService.generateReceiptHTML(receipt);
        const receiptWindow = window.open('', '_blank');
        receiptWindow.document.write(`
          <html><head><title>Custody Receipt #${receipt.receiptId}</title>
          <style>body { font-family: sans-serif; padding: 2rem; background: #f8fafc; }</style>
          </style></head><body>${receiptHTML}
          <button onclick="window.print()" style="margin-top: 1rem; padding: 0.5rem 1rem;">Print Custody Receipt</button>
          </body></html>
        `);
        renderGallery();
      });
    });
  }

  // QR Tag Modal Helper
  function showQRTagModal(title, id) {
    const qrContainer = document.getElementById('qr-modal-container');
    const svgHTML = QRGeneratorService.generatePropertyTagSVG(title, id);
    qrContainer.innerHTML = svgHTML;
    document.getElementById('qr-modal').classList.add('active');
  }

  document.getElementById('close-qr-modal').addEventListener('click', () => {
    document.getElementById('qr-modal').classList.remove('active');
  });

  // Automated Test Harness Runner
  function runTestSuite() {
    const container = document.getElementById('test-results-container');
    const testResults = EngineTestSuite.runAllTests();

    container.innerHTML = `
      <table class="test-table">
        <thead>
          <tr>
            <th>Test Specification</th>
            <th>Result</th>
            <th>Execution Details</th>
          </tr>
        </thead>
        <tbody>
          ${testResults.map(t => `
            <tr>
              <td><strong>${t.name}</strong></td>
              <td class="${t.passed ? 'test-pass' : 'test-fail'}">${t.passed ? 'PASSED ✅' : 'FAILED ❌'}</td>
              <td>${t.details}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;
  }

  // Export JSON Backup
  document.getElementById('export-db-btn').addEventListener('click', () => {
    const jsonStr = FoundItAPI.exportDatabaseBackupJSON();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `foundit_database_backup_v3_${Date.now()}.json`;
    a.click();
  });

  // Initial Load
  renderGallery();
});
