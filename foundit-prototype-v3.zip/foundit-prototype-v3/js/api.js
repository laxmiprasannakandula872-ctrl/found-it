/**
 * FoundIt v3.0 Persistence & API Engine
 * Manages sample items, claim records, custody receipts, and storage export/import.
 */

export class FoundItAPI {
  static STORAGE_KEY = 'foundit_items_v3';
  static CLAIMS_KEY = 'foundit_claims_v3';
  static RECEIPTS_KEY = 'foundit_receipts_v3';

  static PLACEHOLDER_IMG = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="300" height="200" viewBox="0 0 300 200"><rect width="300" height="200" fill="%231e293b"/><text x="50%" y="50%" fill="%2338bdf8" font-size="16" font-family="sans-serif" text-anchor="middle">FoundIt Item Photo</text></svg>';

  static INITIAL_ITEMS = [
    {
      id: 'item-1',
      type: 'Lost',
      title: 'Sony WH-1000XM4 Wireless Headphones',
      category: 'Electronics',
      location: 'Library',
      date: '2026-11-19',
      description: 'Black over-ear noise canceling headphones left on 2nd floor desk near quiet zone.',
      photoUrl: FoundItAPI.PLACEHOLDER_IMG,
      status: 'Open',
      createdAt: '2026-11-19T10:00:00.000Z',
      reporterName: 'Student Alex',
      reporterPhone: '555-0144',
      featureVector: [0.92, 0.11, 0.45, 0.78]
    },
    {
      id: 'item-2',
      type: 'Found',
      title: 'Black Sony Headphones in Case',
      category: 'Electronics',
      location: 'Library',
      date: '2026-11-19',
      description: 'Black Sony over-ear headphones in zipper case found at Library security desk.',
      photoUrl: FoundItAPI.PLACEHOLDER_IMG,
      status: 'Open',
      createdAt: '2026-11-19T14:30:00.000Z',
      reporterName: 'Officer Davis',
      reporterPhone: '555-0100',
      featureVector: [0.90, 0.13, 0.44, 0.80]
    },
    {
      id: 'item-3',
      type: 'Lost',
      title: 'Space Gray MacBook Pro 14"',
      category: 'Electronics',
      location: 'Computer Lab 2',
      date: '2026-11-18',
      description: 'Apple laptop with developer stickers on top cover.',
      photoUrl: FoundItAPI.PLACEHOLDER_IMG,
      status: 'Open',
      createdAt: '2026-11-18T16:20:00.000Z',
      reporterName: 'Student Sam',
      reporterPhone: '555-0199',
      featureVector: [0.15, 0.88, 0.72, 0.31]
    },
    {
      id: 'item-4',
      type: 'Found',
      title: 'Apple Notebook Computer',
      category: 'Electronics',
      location: 'Computer Lab 2',
      date: '2026-11-18',
      description: 'Space gray laptop turned in by lab assistant. Lock screen requires password.',
      photoUrl: FoundItAPI.PLACEHOLDER_IMG,
      status: 'Open',
      createdAt: '2026-11-18T18:00:00.000Z',
      reporterName: 'Lab Guard Mark',
      reporterPhone: '555-0122',
      featureVector: [0.17, 0.85, 0.70, 0.33]
    },
    {
      id: 'item-5',
      type: 'Lost',
      title: 'Blue Hydro Flask 32oz',
      category: 'Water Bottles',
      location: 'Gym',
      date: '2026-11-19',
      description: 'Dark blue insulated water bottle with metal straw lid and sticker near bottom.',
      photoUrl: FoundItAPI.PLACEHOLDER_IMG,
      status: 'Open',
      createdAt: '2026-11-19T09:15:00.000Z',
      reporterName: 'Student Jordan',
      reporterPhone: '555-0177'
    },
    {
      id: 'item-6',
      type: 'Found',
      title: 'Blue Water Bottle Flask',
      category: 'Water Bottles',
      location: 'Gym',
      date: '2026-11-19',
      description: 'Stainless steel hydro flask bottle found near basketball court bleachers.',
      photoUrl: FoundItAPI.PLACEHOLDER_IMG,
      status: 'Open',
      createdAt: '2026-11-19T11:45:00.000Z',
      reporterName: 'Staff Mike',
      reporterPhone: '555-0133'
    },
    {
      id: 'item-7',
      type: 'Lost',
      title: 'Campus Student ID Card',
      category: 'ID Cards & Documents',
      location: 'Cafeteria',
      date: '2026-11-17',
      description: 'Student ID card in transparent lanyard badge holder.',
      photoUrl: FoundItAPI.PLACEHOLDER_IMG,
      status: 'Open',
      createdAt: '2026-11-17T13:10:00.000Z',
      reporterName: 'Student David',
      reporterPhone: '555-0188'
    },
    {
      id: 'item-8',
      type: 'Found',
      title: 'Found Student ID & Lanyard',
      category: 'ID Cards & Documents',
      location: 'Cafeteria',
      date: '2026-11-17',
      description: 'ID card turned into Cafeteria cash counter.',
      photoUrl: FoundItAPI.PLACEHOLDER_IMG,
      status: 'Open',
      createdAt: '2026-11-17T14:00:00.000Z',
      reporterName: 'Cafeteria Desk',
      reporterPhone: '555-04412'
    },
    {
      id: 'item-9',
      type: 'Lost',
      title: 'Dorm Room & Bike Keyring',
      category: 'Keys',
      location: 'Main Gate',
      date: '2026-11-18',
      description: 'Set of 3 brass keys on a red leather keychain fob.',
      photoUrl: FoundItAPI.PLACEHOLDER_IMG,
      status: 'Open',
      createdAt: '2026-11-18T08:30:00.000Z',
      reporterName: 'Student Elena',
      reporterPhone: '555-0166'
    },
    {
      id: 'item-10',
      type: 'Found',
      title: 'Keys with Red Fob',
      category: 'Keys',
      location: 'Main Gate',
      date: '2026-11-18',
      description: 'Keys picked up by gate security guard near bus stop.',
      photoUrl: FoundItAPI.PLACEHOLDER_IMG,
      status: 'Open',
      createdAt: '2026-11-18T09:00:00.000Z',
      reporterName: 'Gate Guard John',
      reporterPhone: '555-0111'
    }
  ];

  static initStorage() {
    try {
      if (!localStorage.getItem(this.STORAGE_KEY)) {
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(this.INITIAL_ITEMS));
      }
      if (!localStorage.getItem(this.CLAIMS_KEY)) {
        localStorage.setItem(this.CLAIMS_KEY, JSON.stringify([]));
      }
      if (!localStorage.getItem(this.RECEIPTS_KEY)) {
        localStorage.setItem(this.RECEIPTS_KEY, JSON.stringify([]));
      }
    } catch (e) {
      console.warn('LocalStorage unavailable, running in-memory fallback mode.');
    }
  }

  static getItems() {
    this.initStorage();
    try {
      const data = localStorage.getItem(this.STORAGE_KEY);
      return data ? JSON.parse(data) : this.INITIAL_ITEMS;
    } catch (e) {
      return this.INITIAL_ITEMS;
    }
  }

  static saveItem(newItem) {
    this.initStorage();
    const items = this.getItems();
    items.unshift(newItem);
    try {
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(items));
    } catch (e) {
      console.error('Failed to write item to LocalStorage', e);
    }
    return newItem;
  }

  static updateItemStatus(itemId, status) {
    const items = this.getItems();
    const item = items.find(i => i.id === itemId);
    if (item) {
      item.status = status;
      try {
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(items));
      } catch (e) {
        console.error('Storage status update failed', e);
      }
    }
    return item;
  }

  static submitClaim(claim) {
    this.initStorage();
    let claims = [];
    try {
      const data = localStorage.getItem(this.CLAIMS_KEY);
      claims = data ? JSON.parse(data) : [];
    } catch (e) {
      claims = [];
    }
    claims.unshift(claim);
    try {
      localStorage.setItem(this.CLAIMS_KEY, JSON.stringify(claims));
    } catch (e) {
      console.error('Failed to submit claim to LocalStorage', e);
    }
    this.updateItemStatus(claim.itemId, 'Claim Pending');
    return claim;
  }

  static getClaims() {
    this.initStorage();
    try {
      const data = localStorage.getItem(this.CLAIMS_KEY);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      return [];
    }
  }

  static saveReceipt(receipt) {
    this.initStorage();
    let receipts = [];
    try {
      const data = localStorage.getItem(this.RECEIPTS_KEY);
      receipts = data ? JSON.parse(data) : [];
    } catch (e) {
      receipts = [];
    }
    receipts.unshift(receipt);
    try {
      localStorage.setItem(this.RECEIPTS_KEY, JSON.stringify(receipts));
    } catch (e) {
      console.error('Failed to write receipt', e);
    }
    return receipt;
  }

  static getReceipts() {
    this.initStorage();
    try {
      const data = localStorage.getItem(this.RECEIPTS_KEY);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      return [];
    }
  }

  static exportDatabaseBackupJSON() {
    const backup = {
      version: '3.0',
      exportedAt: new Date().toISOString(),
      items: this.getItems(),
      claims: this.getClaims(),
      receipts: this.getReceipts()
    };
    return JSON.stringify(backup, null, 2);
  }
}
